﻿namespace NUMC.Forms.Controls
{
    partial class DefaultLayout
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button1 = new NUMC.Design.Bright.BrightButton();
            this.Button2 = new NUMC.Design.Bright.BrightButton();
            this.Button3 = new NUMC.Design.Bright.BrightButton();
            this.Button4 = new NUMC.Design.Bright.BrightButton();
            this.Button5 = new NUMC.Design.Bright.BrightButton();
            this.Button6 = new NUMC.Design.Bright.BrightButton();
            this.Button7 = new NUMC.Design.Bright.BrightButton();
            this.Button8 = new NUMC.Design.Bright.BrightButton();
            this.Button9 = new NUMC.Design.Bright.BrightButton();
            this.Button10 = new NUMC.Design.Bright.BrightButton();
            this.Button11 = new NUMC.Design.Bright.BrightButton();
            this.Button12 = new NUMC.Design.Bright.BrightButton();
            this.Button13 = new NUMC.Design.Bright.BrightButton();
            this.Button14 = new NUMC.Design.Bright.BrightButton();
            this.Button15 = new NUMC.Design.Bright.BrightButton();
            this.Button16 = new NUMC.Design.Bright.BrightButton();
            this.Button17 = new NUMC.Design.Bright.BrightButton();
            this.SuspendLayout();
            // 
            // Button1
            // 
            this.Button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button1.Location = new System.Drawing.Point(6, 7);
            this.Button1.Name = "Button1";
            this.Button1.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button1.Size = new System.Drawing.Size(88, 71);
            this.Button1.TabIndex = 0;
            this.Button1.Text = "Num\r\n";
            // 
            // Button2
            // 
            this.Button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button2.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button2.Location = new System.Drawing.Point(100, 7);
            this.Button2.Name = "Button2";
            this.Button2.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button2.Size = new System.Drawing.Size(88, 71);
            this.Button2.TabIndex = 0;
            this.Button2.Text = "/";
            // 
            // Button3
            // 
            this.Button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button3.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button3.Location = new System.Drawing.Point(194, 7);
            this.Button3.Name = "Button3";
            this.Button3.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button3.Size = new System.Drawing.Size(88, 71);
            this.Button3.TabIndex = 0;
            this.Button3.Text = "*";
            // 
            // Button4
            // 
            this.Button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button4.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button4.Location = new System.Drawing.Point(288, 7);
            this.Button4.Name = "Button4";
            this.Button4.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button4.Size = new System.Drawing.Size(88, 71);
            this.Button4.TabIndex = 0;
            this.Button4.Text = "-";
            // 
            // Button5
            // 
            this.Button5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button5.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button5.Location = new System.Drawing.Point(6, 84);
            this.Button5.Name = "Button5";
            this.Button5.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button5.Size = new System.Drawing.Size(88, 71);
            this.Button5.TabIndex = 0;
            this.Button5.Text = "7";
            // 
            // Button6
            // 
            this.Button6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button6.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button6.Location = new System.Drawing.Point(100, 84);
            this.Button6.Name = "Button6";
            this.Button6.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button6.Size = new System.Drawing.Size(88, 71);
            this.Button6.TabIndex = 0;
            this.Button6.Text = "8";
            // 
            // Button7
            // 
            this.Button7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button7.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button7.Location = new System.Drawing.Point(194, 84);
            this.Button7.Name = "Button7";
            this.Button7.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button7.Size = new System.Drawing.Size(88, 71);
            this.Button7.TabIndex = 0;
            this.Button7.Text = "9";
            // 
            // Button8
            // 
            this.Button8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button8.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button8.Location = new System.Drawing.Point(288, 84);
            this.Button8.Name = "Button8";
            this.Button8.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button8.Size = new System.Drawing.Size(88, 148);
            this.Button8.TabIndex = 0;
            this.Button8.Text = "+";
            // 
            // Button9
            // 
            this.Button9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button9.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button9.Location = new System.Drawing.Point(6, 161);
            this.Button9.Name = "Button9";
            this.Button9.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button9.Size = new System.Drawing.Size(88, 71);
            this.Button9.TabIndex = 0;
            this.Button9.Text = "4";
            // 
            // Button10
            // 
            this.Button10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button10.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button10.Location = new System.Drawing.Point(100, 161);
            this.Button10.Name = "Button10";
            this.Button10.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button10.Size = new System.Drawing.Size(88, 71);
            this.Button10.TabIndex = 0;
            this.Button10.Text = "5";
            // 
            // Button11
            // 
            this.Button11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button11.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button11.Location = new System.Drawing.Point(194, 161);
            this.Button11.Name = "Button11";
            this.Button11.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button11.Size = new System.Drawing.Size(88, 71);
            this.Button11.TabIndex = 0;
            this.Button11.Text = "6";
            // 
            // Button12
            // 
            this.Button12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button12.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button12.Location = new System.Drawing.Point(6, 238);
            this.Button12.Name = "Button12";
            this.Button12.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button12.Size = new System.Drawing.Size(88, 71);
            this.Button12.TabIndex = 0;
            this.Button12.Text = "1";
            // 
            // Button13
            // 
            this.Button13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button13.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button13.Location = new System.Drawing.Point(100, 238);
            this.Button13.Name = "Button13";
            this.Button13.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button13.Size = new System.Drawing.Size(88, 71);
            this.Button13.TabIndex = 0;
            this.Button13.Text = "2";
            // 
            // Button14
            // 
            this.Button14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button14.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button14.Location = new System.Drawing.Point(194, 238);
            this.Button14.Name = "Button14";
            this.Button14.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button14.Size = new System.Drawing.Size(88, 71);
            this.Button14.TabIndex = 0;
            this.Button14.Text = "3";
            // 
            // Button15
            // 
            this.Button15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button15.Location = new System.Drawing.Point(288, 238);
            this.Button15.Name = "Button15";
            this.Button15.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button15.Size = new System.Drawing.Size(88, 148);
            this.Button15.TabIndex = 0;
            this.Button15.Text = "Enter";
            // 
            // Button16
            // 
            this.Button16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button16.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button16.Location = new System.Drawing.Point(6, 315);
            this.Button16.Name = "Button16";
            this.Button16.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button16.Size = new System.Drawing.Size(182, 71);
            this.Button16.TabIndex = 0;
            this.Button16.Text = "0";
            // 
            // Button17
            // 
            this.Button17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Button17.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Button17.Location = new System.Drawing.Point(194, 315);
            this.Button17.Name = "Button17";
            this.Button17.Padding = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.Button17.Size = new System.Drawing.Size(88, 71);
            this.Button17.TabIndex = 0;
            this.Button17.Text = ".";
            // 
            // NUMPadUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.Button2);
            this.Controls.Add(this.Button3);
            this.Controls.Add(this.Button4);
            this.Controls.Add(this.Button5);
            this.Controls.Add(this.Button6);
            this.Controls.Add(this.Button7);
            this.Controls.Add(this.Button8);
            this.Controls.Add(this.Button9);
            this.Controls.Add(this.Button10);
            this.Controls.Add(this.Button11);
            this.Controls.Add(this.Button12);
            this.Controls.Add(this.Button13);
            this.Controls.Add(this.Button14);
            this.Controls.Add(this.Button15);
            this.Controls.Add(this.Button16);
            this.Controls.Add(this.Button17);
            this.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.MaximumSize = new System.Drawing.Size(751, 557);
            this.Name = "NUMPadUI";
            this.Size = new System.Drawing.Size(382, 392);
            this.ResumeLayout(false);

        }

        #endregion

        private Design.Bright.BrightButton Button1;
        private Design.Bright.BrightButton Button2;
        private Design.Bright.BrightButton Button3;
        private Design.Bright.BrightButton Button4;
        private Design.Bright.BrightButton Button5;
        private Design.Bright.BrightButton Button6;
        private Design.Bright.BrightButton Button7;
        private Design.Bright.BrightButton Button8;
        private Design.Bright.BrightButton Button9;
        private Design.Bright.BrightButton Button10;
        private Design.Bright.BrightButton Button11;
        private Design.Bright.BrightButton Button12;
        private Design.Bright.BrightButton Button13;
        private Design.Bright.BrightButton Button14;
        private Design.Bright.BrightButton Button15;
        private Design.Bright.BrightButton Button16;
        private Design.Bright.BrightButton Button17;
    }
}
