﻿using System.Collections.Generic;
using System.Windows.Forms;
using WindowsInput.Native;

namespace NUMC.Script
{
    public class Menu
    {
        public static ToolStripItem[] GetSampleItems()
        {
            List<ToolStripItem> SampleItems = new List<ToolStripItem>();

            int[] SeparatorIndex = new int[] { 2, 4, 6, 11 };

            string[] Names = new string[] 
            {
                "실행 취소", 
                "다시 실행", 
                "브러시 확대", 
                "브러쉬 축소", 
                "확대", 
                "축소", 
                "브러시", 
                "지우개", 
                "페인트",
                "손", 
                "돋보기", 
                "사용 안함"
            };

            KeyObject[] KeyObjects = new KeyObject[]
            {
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.CONTROL, VirtualKeyCode.VK_Z }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.CONTROL, VirtualKeyCode.SHIFT, VirtualKeyCode.VK_Z }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.OEM_6 }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.OEM_4 }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.CONTROL, VirtualKeyCode.OEM_PLUS }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.CONTROL, VirtualKeyCode.OEM_MINUS }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.VK_B }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.VK_E }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.VK_G }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.SPACE }),
                NewKeyObjectVirtualKey(new VirtualKeyCode[] { VirtualKeyCode.VK_Z }),
                DisableMenuItem()
            };

            for (int i = 0; i < Names.Length; i++)
            {
                for (int si = 0; si < SeparatorIndex.Length; si++)
                {
                    if (i == SeparatorIndex[si])
                    {
                        SampleItems.Add(new ToolStripSeparator());
                        break;
                    }
                }

                ToolStripItem item = new ToolStripMenuItem();
                item.Text = Names[i];
                item.Tag = KeyObjects[i];
                SampleItems.Add(item);
            }

            return SampleItems.ToArray();
        }


        public static KeyObject NewKeyObjectVirtualKey(VirtualKeyCode[] virtualKeys)
        {
            return new KeyObject
            (
                Keys.None,
                true,
                new KeyScript[]
                {
                    new KeyScript
                    (
                        "VirtualKey",
                        null,
                        new VirtualKey
                        (
                            virtualKeys
                        )
                    )
                }
            );
        }

        public static KeyObject DisableMenuItem()
        {
            return new KeyObject
            (
                Keys.None,
                false,
                null
            );
        }
    }
}
