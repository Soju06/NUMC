﻿using DarkUI.Forms;
using System;
using System.Diagnostics;
using System.Windows.Forms;
using WindowsInput.Native;

namespace NUMC.Forms.Dialogs
{
    public partial class KeyAddDialog : DarkDialog
    {
        public bool IsVirtual { get; internal set; }
        public Keys Key { get; internal set; }
        public VirtualKeyCode VirtualKey { get; internal set; }

        public KeyAddDialog(bool isVirtual)
        {
            InitializeComponent();
            titleBar.Form = this;
            IsVirtual = isVirtual;

            if (IsVirtual)
                MainComboBox.DataSource = Enum.GetValues(typeof(VirtualKeyCode));
            else
                MainComboBox.DataSource = Enum.GetValues(typeof(Keys));

            MainComboBox.SelectedIndex = 0;
        }

        private void MainComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (IsVirtual)
                VirtualKey = (VirtualKeyCode)MainComboBox.SelectedValue;
            else
                Key = (Keys)MainComboBox.SelectedValue;
        }

        private void InfoButton_Click(object sender, EventArgs e)
        {
            Process.Start(new ProcessStartInfo(@"http://www.kbdedit.com/manual/low_level_vk_list.html"));
        }

        private void KeyAddDialog_Load(object sender, EventArgs e)
        {
            MainComboBox.Refresh();
        }
    }
}
