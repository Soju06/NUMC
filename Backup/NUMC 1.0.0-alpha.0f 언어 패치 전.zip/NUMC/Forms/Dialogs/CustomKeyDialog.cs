﻿using DarkUI.Forms;
using Hook;
using NUMC.Script;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Windows.Input;
using WindowsInput.Native;

namespace NUMC.Forms.Dialogs
{
    public partial class CustomKeyDialog : DarkDialog
    {
        public string[,] Types = new string[4, 3]
        {
            {
                "SendKeys",
                "기본 키",
                "일부 특수키 사용이 불가능 합니다. (WinKey)\n짧은 문자열 입력, 간단한 단축키 지정에 접합합니다.\n눌렀다 떼기가 불가능합니다."
            },
            {
                "VirtualSendKeys",
                "가상 동시 입력",
                "키보드 전체를 제어할 수 있습니다.\n눌렀다 떼기를 사용하지 않은 단일 단축키에 적합합니다.\n눌렀다 떼기가 불가능합니다."
            },
            {
                "TextEntry",
                "문자열 입력",
                "문자열 입력만 가능합니다."
            },
            {
                "VirtualKey",
                "가상 키",
                "키보드 전체를 제어할 수 있습니다.\n눌렀다 떼기를 지원합니다.\n단축키 지정에 적합합니다.\n문자열 입력에 부적합합니다."
            }
        };

        public KeyScript KeyScript { get; internal set; }

        public CustomKeyDialog(KeyScript keyScript)
        {
            KeyScript = keyScript;

            InitializeComponent();
            InitializeComboBox();
            InitializeSetting();

            btnOk.Click += BtnOk_Click;

            titleBar.Form = this;
            titleBar.Title = Setting.Setting.GetTitleName("Custom Key Wizard");
            KeyboardHook.KeyDown += KeyboardHook_KeyDown;
        }

        private void InitializeComboBox()
        {
            for (int i = 0; i < Types.GetLength(0); i++)
            {
                KeyboardTypeComboBox.Items.Add(Types[i, 1]);
            }

            KeyboardTypeComboBox.SelectedIndex = 3;
        }

        public void InitializeSetting()
        {
            if(KeyScript != null)
            {
                for (int i = 0; i < Types.GetLength(0); i++)
                    if (KeyScript.Type == Types[i, 0])
                    {
                        KeyboardTypeComboBox.SelectedIndex = i;
                        
                        if(KeyboardTypeComboBox.SelectedIndex == 0 && KeyboardTypeComboBox.SelectedIndex == 2)
                        {
                            if (KeyScript.SendKeys != null && KeyScript.SendKeys.Text != null)
                                ScriptTextBox.Text = string.Join("\n", KeyScript.SendKeys.Text);
                        }
                        else
                        {
                            if (KeyScript.VirtualKey != null && KeyScript.VirtualKey.Keys != null)
                            {
                                ScriptTextBox.Text = string.Join(", ", KeyScript.VirtualKey.Keys);
                            }
                        }
                    }
            }
        }

        private void CustomKey_Load(object sender, EventArgs e)
        {
            KeyboardTypeComboBox.Refresh();
        }

        private void CustomKey_FormClosing(object sender, FormClosingEventArgs e)
        {
            KeyboardHook.KeyDown -= KeyboardHook_KeyDown;
        }

        private bool KeyboardHook_KeyDown(int vkCode)
        {
            if (hook && VirtualMode && ScriptTextBox.Text.Split(',').Length <= 25)
            {
                AddVirtualKey((VirtualKeyCode)vkCode);
            }
            return !hook;
        }

        private void AddVirtualKey(VirtualKeyCode keyCode)
        {
            if (string.IsNullOrWhiteSpace(ScriptTextBox.Text))
                ScriptTextBox.AppendText((keyCode).ToString());
            else
            {
                ScriptTextBox.AppendText(", ");
                ScriptTextBox.AppendText((keyCode).ToString());
            }
        }

        private void DeleteVirtualKey()
        {
            string[] ary = ScriptTextBox.Text.Replace(" ", "").Split(',');
            ScriptTextBox.Text = string.Join(", ", ary, 0, ary.Length - 1);
        }

        private void KeyboardTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            hook = false;
            TipLabel.Text = Types[KeyboardTypeComboBox.SelectedIndex, 2];
            ScriptTextBox.Text = string.Empty;
        }

        private void KeyTextBox_MouseHover(object sender, EventArgs e)
        {
            TipBox.ToolTipTitle = "후킹을 사용하려면...";
            TipBox.SetToolTip((Control)sender, "텍스트 박스에 마우스가 있으면 키 후킹을 시작합니다.\n후킹 중 입니다.");
        }

        bool hook = false;

        private void KeyTextBox_Enter(object sender, EventArgs e)
        {
            if (VirtualMode)
                hook = true;
        }

        private void KeyTextBox_Leave(object sender, EventArgs e)
        {
            hook = false;
        }

        private void KeyTextBox_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (VirtualMode) // 문자열 입력이 아니면
            {
                // 백스페이스
                if (e.KeyCode == Keys.Back)
                    DeleteVirtualKey();
                e.SuppressKeyPress = true;
                e.Handled = true;
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (VirtualMode)
            {
                DeleteVirtualKey();
            }
        }

        private bool VirtualMode
        {
            get
            {
                return KeyboardTypeComboBox.SelectedIndex != 0 && KeyboardTypeComboBox.SelectedIndex != 2;
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            ScriptTextBox.Text = string.Empty;
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            if (VirtualMode && ScriptTextBox.Text.Split(',').Length > 25)
                return;

            using (KeyAddDialog addDialog = new KeyAddDialog(VirtualMode))
            {
                if (addDialog.ShowDialog() == DialogResult.OK)
                {
                    if (addDialog.IsVirtual)
                        AddVirtualKey(addDialog.VirtualKey);
                    else
                        ScriptTextBox.AppendText(addDialog.Key.ToString());
                }
                addDialog.Dispose();
            }
        }

        private VirtualKeyCode[] GetVirtualKeys()
        {
            List<VirtualKeyCode> virtualKeys = new List<VirtualKeyCode>();
            string[] ary = ScriptTextBox.Text.Replace(" ", "").Split(',');
            for (int i = 0; i < ary.Length; i++)
            {
                if (Enum.TryParse(ary[i], out VirtualKeyCode keyCode))
                    virtualKeys.Add(keyCode);
            }

            return virtualKeys.ToArray();
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            if (KeyScript == null)
                KeyScript = new KeyScript();

            if (string.IsNullOrWhiteSpace(ScriptTextBox.Text))
            {
                KeyScript.SendKeys = null;
                KeyScript.VirtualKey = null;
            }
            else
            {

                if (VirtualMode)
                {
                    VirtualKeyCode[] virtualKeys = GetVirtualKeys();

                    KeyScript.SendKeys = null;

                    if (virtualKeys.Length == 0)
                    {
                        KeyScript.VirtualKey = null;
                    }
                    else
                    {
                        VirtualKey virtualKey = new VirtualKey(virtualKeys);

                        KeyScript.VirtualKey = virtualKey;
                    }
                }
                else
                {
                    Script.SendKeys sendKeys = new Script.SendKeys(new string[] { ScriptTextBox.Text });

                    KeyScript.VirtualKey = null;
                    KeyScript.SendKeys = sendKeys;
                }
            }

            KeyScript.Type = Types[KeyboardTypeComboBox.SelectedIndex, 0];
        }
    }
}
