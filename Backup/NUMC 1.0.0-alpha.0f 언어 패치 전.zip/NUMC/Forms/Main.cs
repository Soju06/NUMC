﻿using DarkUI.Forms;
using Hook;
using NUMC.Forms.Dialogs;
using NUMC.Script;
using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace NUMC
{
    public partial class Main : Form
    {
        private Script.Script Script = new Script.Script();
        private Keys SelectedKey;

        public Main()
        {
            InitializeComponent();
            InitializeForm();
            InitializeSetting();
            InitializeSampleItems();
            InitializeEvents();

            KeyboardHook.KeyDown += KeyboardHook_KeyDown;
            KeyboardHook.KeyUp += KeyboardHook_KeyUp;
            KeyboardHook.HookStart();
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                return;
            }
            KeyboardHook.HookEnd();
            Script.StopInput();
        }

        #region KeyboardHook

        private bool KeyboardHook_KeyUp(int vkCode)
        {
            if (Script.Object.WVKeys.Contains((Keys)vkCode))
            {
                Script.KeyUp(vkCode);
                return !Script.GetIgnoreStatus((Keys)vkCode);
            }
            else
                return true;
        }

        private bool KeyboardHook_KeyDown(int vkCode)
        {
            if (Script.Object.WVKeys.Contains((Keys)vkCode))
            {
                Script.KeyDown(vkCode);
                return !Script.GetIgnoreStatus((Keys)vkCode);
            }
            else
                return true;
        }

        #endregion KeyboardHook

        #region Initialize

        private void InitializeForm()
        {
            TitleBar.Form = this;
            FormBorderStyle = FormBorderStyle.None;
            DoubleBuffered = true;
            SetStyle(ControlStyles.ResizeRedraw, true);

            SetStyle(ControlStyles.DoubleBuffer, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.UserPaint, true);

            Text = Setting.Setting.TITLE_NAME;
            TitleBar.Title = Setting.Setting.GetTitleName("Setting");
        }

        private void InitializeSetting()
        {
            if (File.Exists(Setting.Setting.KEY_SETTING_PATH))
            {
                LoadSetting();
            }
            else
            {
                Script.Object.Clear(Script.Object.WVKeys);
                SaveSetting();
            }

            StartProgramMenuItem.Checked = Setting.Setting.StartProgram;
        }

        private void InitializeSampleItems()
        {
            NUMContextMenu.Items.AddRange(NUMC.Script.Menu.GetSampleItems());
        }

        private void InitializeEvents()
        {
            NumPadUI.MouseClick += NumPadUI_MouseClick;

            for (int i = 0; i < NUMContextMenu.Items.Count; i++)
            {
                if (NUMContextMenu.Items[i].GetType() == typeof(ToolStripMenuItem))
                {
                    NUMContextMenu.Items[i].Click += MenuItem_Click;
                }
            }

            for (int i = 0; i < ApplicationContextMenu.Items.Count; i++)
            {
                if (ApplicationContextMenu.Items[i].GetType() == typeof(ToolStripMenuItem))
                {
                    ApplicationContextMenu.Items[i].Click += ApplicationMenuItem_Click;
                }
            }

            for (int i = 0; i < NotifyIconContextMenu.Items.Count; i++)
            {
                if (NotifyIconContextMenu.Items[i].GetType() == typeof(ToolStripMenuItem))
                {
                    NotifyIconContextMenu.Items[i].Click += ApplicationMenuItem_Click;
                }
            }
        }

        #endregion Initialize

        #region Move

        private const int cGrip = 16;
        private const int cCaption = 32;

        private Pen Pen = new Pen(Color.FromArgb(34, 34, 34));

        protected override void OnPaint(PaintEventArgs e)
        {
            Rectangle rc = new Rectangle(ClientSize.Width - cGrip, ClientSize.Height - cGrip, cGrip, cGrip);
            ControlPaint.DrawSizeGrip(e.Graphics, BackColor, rc);
            rc = new Rectangle(0, 0, ClientSize.Width, cCaption);
            e.Graphics.FillRectangle(Pen.Brush, rc);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x84)
            {  // Trap WM_NCHITTEST
                Point pos = new Point(m.LParam.ToInt32());
                pos = PointToClient(pos);
                if (pos.Y < cCaption)
                {
                    m.Result = (IntPtr)2;
                    return;
                }
                if (pos.X >= ClientSize.Width - cGrip && pos.Y >= ClientSize.Height - cGrip)
                {
                    m.Result = (IntPtr)17;
                    return;
                }
            }
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= 0x20000;
                return cp;
            }
        }

        #endregion Move

        #region Setting

        private void SaveSetting()
        {
            File.WriteAllText(Setting.Setting.KEY_SETTING_PATH, Script.Object.ToString());
        }

        private void LoadSetting()
        {
            try
            {
                Script.Object.SetScript(File.ReadAllText(Setting.Setting.KEY_SETTING_PATH));
            }
            catch (Exception ex)
            {
                if (DarkMessageBox.ShowError($"설정 불러오기 실패!\n설정을 초기화 하시겠습니까?\n\n메시지:\n{ex.Message.Split('\n')[0]}",
                    Setting.Setting.TITLE_NAME, DarkDialogButton.YesNo) == DialogResult.Yes)
                {
                    Script.Object.Reset();
                    SaveSetting();
                }
            }
        }

        #endregion Setting

        #region ToolStripMenuItem_Click

        private void MenuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem menu = (ToolStripMenuItem)sender;

            // 샘플 이라면
            if (menu.Tag != null && menu.Tag.GetType().FullName == typeof(KeyObject).FullName)
            {
                KeyObject SampleScript = (KeyObject)menu.Tag;
                KeyObject script = Script.Object.GetKeyObject(SelectedKey, false);
                script.KeyScript = SampleScript.KeyScript;
                script.Ignore = SampleScript.Ignore;
            }
            else if (menu == CustomKeyToolStripMenuItem) // 사용자 지정이라면
            {
                CustomKeySeting();
            }

            SaveSetting();
        }

        private void ApplicationMenuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem menu = (ToolStripMenuItem)sender;

            switch (menu.Tag)
            {
                case "Open":
                    Show();
                    break;

                case "Exit":
                    Application.Exit();
                    break;

                case "JsonEdit":
                    if (DarkMessageBox.ShowWarning("이 메뉴는 실험용 입니다!\n이 메뉴를 사용하면 프로그램이 불안전할 수 있습니다!\n계속 하시겠습니까?",
                        Setting.Setting.TITLE_NAME, DarkDialogButton.YesNo) != DialogResult.Yes)
                        return;
                    using (EditJsonDialog jsonDialog = new EditJsonDialog(Script))
                    {
                        if (jsonDialog.ShowDialog() == DialogResult.OK)
                        {
                            LoadSetting();
                        }
                        GC.Collect();
                    }
                    break;

                case "StartProgram":
                    Setting.Setting.StartProgram = !StartProgramMenuItem.Checked;
                    StartProgramMenuItem.Checked = Setting.Setting.StartProgram;
                    break;
            }
        }

        #endregion ToolStripMenuItem_Click

        #region OpenKeySettingDialog

        private void CustomKeySeting()
        {
            Keys keys = SelectedKey;
            KeyObject keyObject = Script.Object.GetKeyObject(keys, false);
            KeyScript keyScript;

            if (keyObject != null && keyObject.KeyScript != null && keyObject.KeyScript.Length >= 1)
                keyScript = keyObject.KeyScript[0];
            else
                keyScript = (keyObject.KeyScript = new KeyScript[] { new KeyScript() })[0];

            using (CustomKeyDialog customKey = new CustomKeyDialog(keyScript))
            {
                if (customKey.ShowDialog() == DialogResult.OK)
                {
                    // 확인
                }
            }

            GC.Collect(1);
        }

        #endregion OpenKeySettingDialog

        private void NumPadUI_MouseClick(Keys Key, MouseButtons Button)
        {
            SelectedKey = Key;
            SetNUMContextMenuCheck();
            NUMContextMenu.Show(MousePosition);
        }

        private void SetNUMContextMenuCheck()
        {
            bool s = false;

            Keys keys = SelectedKey;
            KeyObject keyObject = Script.Object.GetKeyObject(keys, false);

            keyObject.Key = 0;
            JavaScriptSerializer serializer = new JavaScriptSerializer();

            string kobj = serializer.Serialize(keyObject);
            keyObject.Key = keys;

            for (int i = 0; i < NUMContextMenu.Items.Count; i++)
            {
                if (NUMContextMenu.Items[i].GetType() == typeof(ToolStripMenuItem))
                {
                    KeyObject menuObject = (KeyObject)NUMContextMenu.Items[i].Tag;
                    if (((ToolStripMenuItem)NUMContextMenu.Items[i]).Checked = serializer.Serialize(menuObject) == kobj)
                        s = true;
                }
            }

            if (!s && keyObject.KeyScript != null)
                CustomKeyToolStripMenuItem.Checked = true;
        }

        private void notifyIcon_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                Show();
            else
                NotifyIconContextMenu.Show(MousePosition);
        }
    }
}