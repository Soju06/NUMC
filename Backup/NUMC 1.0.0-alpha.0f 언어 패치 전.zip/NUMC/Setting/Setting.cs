﻿using DarkUI.Forms;
using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace NUMC.Setting
{
    public class Setting
    {
        public static string KEY_SETTING_PATH = Path.Combine(Application.StartupPath, $"{Process.GetCurrentProcess().ProcessName}.json");

        public static string TITLE_NAME = "NUMC - Portable";

        public static string GetTitleName(string subtitle)
        {
            return string.Format("NUMC {0} - Portable", subtitle);
        }

        private static RegistryKey RunRegKey;

        static Setting()
        {
            try
            {
                RunRegKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
            }
            catch (Exception ex)
            {
                DarkMessageBox.ShowError($"Start program check failed!\n{ex.Message}", TITLE_NAME);
            }
        }

        public static bool StartProgram
        {
            get
            {
                try
                {
                    return RunRegKey.GetValue(TITLE_NAME) != null;
                }
                catch { }
                return false;
            }
            set
            {
                try
                {
                    if (value)
                    {
                        RunRegKey.SetValue(TITLE_NAME, Application.ExecutablePath.Replace('/', '\\'));
                    }
                    else
                    {
                        RunRegKey.DeleteValue(TITLE_NAME, false);
                    }
                }
                catch (Exception ex) 
                {
                    DarkMessageBox.ShowError($"Start program change failed!\n{ex.Message}", TITLE_NAME);
                }
            }
        }
    }
}