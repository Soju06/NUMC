﻿namespace Hook
{
    public enum KeyboardEventType
    {
        KEYDOWN,
        KEYUP,
        KEYCLICK
    }
}