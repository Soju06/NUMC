﻿using NUMC.Design;
using NUMC.Design.Bright;
using NUMC.Script;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NUMC.Forms.Dialogs.Macro
{
    public partial class SetSettingDialog : NDialog
    {
        public string Path { get; internal set; }

        public SetSettingDialog()
        {
            InitializeComponent();

            titleBar.Form = this;

            titleBar.Title = Setting.Setting.GetTitleName(Language.Language.SetSettingDialog_Title);

            fileDropControl.FileChanged += FileDropControl_FileChanged;
            fileDropControl.Filter = "Json Files|*.json|All Files|*.*";
            fileDropControl.AllowExtensions = new string[] { ".json" };
        }

        private void FileDropControl_FileChanged(object sender, EventArgs e)
        {
            Path = fileDropControl.File;
        }
    }
}