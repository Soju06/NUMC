﻿namespace NUMC.Design.Bright
{
    public enum BrightControlState
    {
        Normal,
        Hover,
        Pressed
    }
}
